<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once VISIONI_PLATFORM_DIR . 'includes/class-visioni-platform-radar.php';
require_once VISIONI_PLATFORM_DIR . 'includes/class-visioni-platform-modules.php';

class Visioni_Platform {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ), 30 );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
        add_action( 'admin_notices', array( __CLASS__, 'render_activation_notice' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
        add_shortcode( 'visioni_platform_app', array( __CLASS__, 'render_platform_app' ) );

        Visioni_Platform_Radar::init();
        Visioni_Platform_Modules::init();
    }

    public static function on_activation() {
        self::ensure_platform_pages();
        flush_rewrite_rules();
        set_transient( 'visioni_platform_show_activation_notice', 1, 5 * MINUTE_IN_SECONDS );
    }

    public static function register_admin_menu() {
        add_menu_page(
            'Visioni Platform',
            'Visioni Platform',
            'manage_options',
            'visioni-platform',
            array( __CLASS__, 'render_dashboard' ),
            'dashicons-admin-site-alt3',
            4
        );

        add_submenu_page(
            'visioni-platform',
            'Guida Utilizzo',
            'Guida Utilizzo',
            'manage_options',
            'visioni-platform-guida',
            array( __CLASS__, 'render_usage_guide' )
        );
    }

    public static function register_settings() {
        register_setting( 'visioni_platform_settings_group', 'visioni_platform_google_maps_key' );
        register_setting( 'visioni_platform_settings_group', 'visioni_platform_firebase_sender_id' );

        if ( isset( $_POST['visioni_platform_generate_pages'] ) && check_admin_referer( 'visioni_platform_generate_pages_action' ) ) {
            self::ensure_platform_pages();
            set_transient( 'visioni_platform_pages_generated', 1, 120 );
        }
    }

    public static function enqueue_assets() {
        wp_register_style(
            'visioni-platform-app',
            VISIONI_PLATFORM_URL . 'assets/css/visioni-platform-app.css',
            array(),
            VISIONI_PLATFORM_VERSION
        );

        wp_register_script(
            'visioni-platform-app',
            VISIONI_PLATFORM_URL . 'assets/js/visioni-platform-app.js',
            array(),
            VISIONI_PLATFORM_VERSION,
            true
        );
    }

    public static function render_dashboard() {
        ?>
        <div class="wrap">
            <h1>Visioni Platform</h1>
            <p>Plugin separato per l'evoluzione della piattaforma Visioni a fasi, senza impattare il core gestionale attuale.</p>

            <p>
                <a class="button button-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=visioni-platform-guida' ) ); ?>">
                    Apri Guida Utilizzo
                </a>
            </p>

            <form method="post" style="margin:14px 0 22px;">
                <?php wp_nonce_field( 'visioni_platform_generate_pages_action' ); ?>
                <input type="hidden" name="visioni_platform_generate_pages" value="1" />
                <button type="submit" class="button button-primary">Genera/Aggiorna pagine piattaforma</button>
                <span style="margin-left:10px;color:#50575e;">Crea automaticamente gli URL radar, my-area, memoria, advisor, ecc.</span>
            </form>

            <h2 style="margin-top:24px;">Stato Moduli</h2>
            <ul style="list-style:disc; margin-left:18px;">
                <li><strong>Radar:</strong> struttura base pronta</li>
                <li><strong>Momento:</strong> pianificato</li>
                <li><strong>Memoria:</strong> pianificato</li>
                <li><strong>Altri moduli:</strong> pianificati</li>
            </ul>

            <h2 style="margin-top:24px;">Configurazione</h2>
            <form method="post" action="options.php" style="max-width:760px;">
                <?php settings_fields( 'visioni_platform_settings_group' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="visioni_platform_google_maps_key">Google Maps API Key</label></th>
                        <td>
                            <input
                                id="visioni_platform_google_maps_key"
                                name="visioni_platform_google_maps_key"
                                type="text"
                                class="regular-text"
                                value="<?php echo esc_attr( (string) get_option( 'visioni_platform_google_maps_key', '' ) ); ?>"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="visioni_platform_firebase_sender_id">Firebase Sender ID</label></th>
                        <td>
                            <input
                                id="visioni_platform_firebase_sender_id"
                                name="visioni_platform_firebase_sender_id"
                                type="text"
                                class="regular-text"
                                value="<?php echo esc_attr( (string) get_option( 'visioni_platform_firebase_sender_id', '' ) ); ?>"
                            />
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-primary">Salva impostazioni piattaforma</button>
                </p>
            </form>
        </div>
        <?php
    }

    public static function render_platform_app() {
        wp_enqueue_style( 'visioni-platform-app' );
        wp_enqueue_script( 'visioni-platform-app' );

        ob_start();
        ?>
        <section class="visioni-platform-app">
            <header class="visioni-platform-app__header">
                <p class="visioni-platform-app__eyebrow">2D Platform</p>
                <h2>Hub Cliente Visioni</h2>
                <p>Da qui il cliente entra in Radar, Memoria, Advisor e negli altri moduli. Se il browser lo supporta, puo installare l'app come PWA.</p>
                <button type="button" id="visioni-platform-install" class="visioni-platform-app__install">Installa App</button>
            </header>
            <div class="visioni-platform-app__grid">
                <a href="<?php echo esc_url( home_url( '/radar/' ) ); ?>">Radar</a>
                <a href="<?php echo esc_url( home_url( '/anticipa/' ) ); ?>">Anticipa</a>
                <a href="<?php echo esc_url( home_url( '/eredita/' ) ); ?>">Eredita</a>
                <a href="<?php echo esc_url( home_url( '/distretto/' ) ); ?>">Distretto</a>
                <a href="<?php echo esc_url( home_url( '/live/' ) ); ?>">Live</a>
                <a href="<?php echo esc_url( home_url( '/profezia/' ) ); ?>">Profezia</a>
                <a href="<?php echo esc_url( home_url( '/my-area/memoria/' ) ); ?>">Memoria</a>
                <a href="<?php echo esc_url( home_url( '/my-area/advisor/' ) ); ?>">Advisor</a>
                <a href="<?php echo esc_url( home_url( '/my-area/vicinato/' ) ); ?>">Vicinato</a>
                <a href="<?php echo esc_url( home_url( '/my-area/ambassador/' ) ); ?>">Ambassador</a>
            </div>
        </section>
        <?php

        return (string) ob_get_clean();
    }

    public static function render_usage_guide() {
        ?>
        <div class="wrap">
            <h1>Visioni Platform - Istruzioni di Utilizzo</h1>
            <p>Questa guida e visibile subito dopo l'attivazione del plugin e resta sempre accessibile da menu <strong>Visioni Platform > Guida Utilizzo</strong>.</p>

            <h2>1) Configurazione iniziale</h2>
            <ol>
                <li>Vai in <strong>Visioni Platform > Visioni Platform</strong>.</li>
                <li>Compila eventuale <strong>Google Maps API Key</strong> (facoltativa).</li>
                <li>Salva le impostazioni.</li>
            </ol>

            <h2>2) Attivare il modulo Radar sul frontend</h2>
            <ol>
                <li>Crea una pagina WordPress (es. "Radar").</li>
                <li>Inserisci lo shortcode <code>[visioni_radar_form]</code>.</li>
                <li>Pubblica la pagina e verifica il wizard a 4 step.</li>
            </ol>

            <h2>3) Verifiche rapide</h2>
            <ul style="list-style:disc; margin-left:18px;">
                <li>Endpoint profili: <code>/wp-json/visioni-platform/v1/radar/profiles</code></li>
                <li>Endpoint immobili: <code>/wp-json/visioni-platform/v1/radar/immobili</code></li>
                <li>Endpoint compatibilita: <code>/wp-json/visioni-platform/v1/radar/compatibility</code></li>
            </ul>

            <h2>4) Flusso operativo consigliato</h2>
            <ol>
                <li>Attiva plugin.</li>
                <li>Configura chiavi/API in dashboard.</li>
                <li>Pubblica pagina Radar con shortcode.</li>
                <li>Testa creazione profilo e ricerca compatibilita.</li>
            </ol>
        </div>
        <?php
    }

    public static function render_activation_notice() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( ! get_transient( 'visioni_platform_show_activation_notice' ) ) {
            if ( get_transient( 'visioni_platform_pages_generated' ) ) {
                delete_transient( 'visioni_platform_pages_generated' );
                ?>
                <div class="notice notice-success is-dismissible">
                    <p><strong>Visioni Platform:</strong> pagine piattaforma aggiornate correttamente.</p>
                </div>
                <?php
            }
            return;
        }

        delete_transient( 'visioni_platform_show_activation_notice' );

        $guide_url = admin_url( 'admin.php?page=visioni-platform-guida' );
        ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <strong>Visioni Platform attivato.</strong>
                Apri subito la guida: <a href="<?php echo esc_url( $guide_url ); ?>">Visioni Platform > Guida Utilizzo</a>.
            </p>
        </div>
        <?php
    }

    public static function ensure_platform_pages() {
        $hub_id = self::upsert_page( 'Platform', 'platform', '[visioni_platform_app]' );

        self::upsert_page( 'Radar', 'radar', '[visioni_radar_form]' );
        self::upsert_page( 'Anticipa', 'anticipa', '[visioni_anticipa]' );
        self::upsert_page( 'Eredita', 'eredita', '[visioni_eredita]' );
        self::upsert_page( 'Distretto', 'distretto', '[visioni_distretto]' );
        self::upsert_page( 'Live', 'live', '[visioni_live]' );
        self::upsert_page( 'Profezia', 'profezia', '[visioni_profezia]' );

        $my_area_id = self::upsert_page( 'My Area', 'my-area', '[visioni_my_area]' );
        self::upsert_page( 'Memoria', 'memoria', '[visioni_memoria]', (int) $my_area_id );
        self::upsert_page( 'Advisor', 'advisor', '[visioni_advisor]', (int) $my_area_id );
        self::upsert_page( 'Vicinato', 'vicinato', '[visioni_vicinato]', (int) $my_area_id );
        self::upsert_page( 'Ambassador', 'ambassador', '[visioni_ambassador]', (int) $my_area_id );
        self::upsert_page( 'Live Area', 'live', '[visioni_live]', (int) $my_area_id );
        self::upsert_page( 'Cantiere', 'cantiere', '[visioni_cantiere]', (int) $my_area_id );

        if ( $hub_id ) {
            update_option( 'visioni_platform_hub_page_id', (int) $hub_id );
        }
    }

    private static function upsert_page( $title, $slug, $content, $parent = 0 ) {
        $path = $parent > 0 ? ( get_post_field( 'post_name', $parent ) . '/' . $slug ) : $slug;
        $page = get_page_by_path( $path );

        $args = array(
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_content' => $content,
            'post_parent'  => (int) $parent,
        );

        if ( $page instanceof WP_Post ) {
            $args['ID'] = $page->ID;
            $updated = wp_update_post( $args, true );
            return is_wp_error( $updated ) ? 0 : (int) $updated;
        }

        $created = wp_insert_post( $args, true );
        return is_wp_error( $created ) ? 0 : (int) $created;
    }
}
